from pathlib import Path
from runtime.config import resolve_path
from runtime.utils import utc_now, sha256_hex, write_json


class ReceiptWriter:
    def __init__(self, cfg):
        self.cfg = cfg
        self.root = resolve_path(cfg, cfg["receipts"]["dir"])

    def emit(self, task_id: str, step: str, status: str, inputs=None, outputs=None, error=None) -> Path:
        created_at = utc_now()
        date_part = created_at.split("T", 1)[0].replace("-", "")
        target_dir = self.root / date_part
        target_dir.mkdir(parents=True, exist_ok=True)
        receipt = {
            "receipt_id": f"{task_id}-{step}-{created_at.replace(':','').replace('+','_')}",
            "task_id": task_id,
            "step": step,
            "status": status,
            "created_at": created_at,
            "inputs_sha256": sha256_hex(inputs or {}),
            "outputs_sha256": sha256_hex(outputs or {}),
            "inputs": inputs or {},
            "outputs": outputs or {},
            "error": error,
        }
        path = target_dir / f"{receipt['receipt_id']}.json"
        write_json(path, receipt)
        return path
